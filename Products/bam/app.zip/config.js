﻿; var config = {
	css:[
	],
    scripts: [
            // "~/bam/js/<script>" or "~/scripts/<script>"
            // add a list of script paths, absolute or application relative with ~
            "~/js/bs.typeahead.util.js",
            "~/js/friendlyDate.js",
            "~/js/edit.js",
            "~/js/designable.js"
    ]
};